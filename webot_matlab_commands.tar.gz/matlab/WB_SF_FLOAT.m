function value = WB_SF_FLOAT
value = 3;
