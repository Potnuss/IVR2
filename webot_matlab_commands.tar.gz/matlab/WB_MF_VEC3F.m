function value = WB_MF_VEC3F
value = 21;
