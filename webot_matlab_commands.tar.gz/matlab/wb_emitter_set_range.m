function wb_emitter_set_range(tag, range)
% Usage: wb_emitter_set_range(tag, range)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_emitter_set_range', tag, range);
