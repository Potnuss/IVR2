function value = WB_ROBOT_KEYBOARD_NUMPAD_UP
value = 377;
