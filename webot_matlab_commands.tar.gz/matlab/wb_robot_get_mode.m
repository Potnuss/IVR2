function result = wb_robot_get_mode()
% Usage: wb_robot_get_mode()
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_robot_get_mode');
