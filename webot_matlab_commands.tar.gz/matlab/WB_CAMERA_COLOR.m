function value = WB_CAMERA_COLOR
value = 99;
