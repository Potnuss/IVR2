function value = WB_NODE_PEN
value = 72;
