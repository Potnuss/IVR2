function value = WB_ROBOT_KEYBOARD_NUMPAD_RIGHT
value = 378;
