/*
    This file is used by the loadlibrary() function in the launcher.m (MATLAB) file.
    It contains all the headers files of Webots C-API.
*/

#define WB_MATLAB_LOADLIBRARY

#include "../../include/controller/c/webots/accelerometer.h"
#include "../../include/controller/c/webots/camera.h"
#include "../../include/controller/c/webots/compass.h"
#include "../../include/controller/c/webots/connector.h"
#include "../../include/controller/c/webots/differential_wheels.h"
#include "../../include/controller/c/webots/display.h"
#include "../../include/controller/c/webots/distance_sensor.h"
#include "../../include/controller/c/webots/emitter.h"
#include "../../include/controller/c/webots/gps.h"
#include "../../include/controller/c/webots/gyro.h"
#include "../../include/controller/c/webots/led.h"
#include "../../include/controller/c/webots/light_sensor.h"
#include "../../include/controller/c/webots/pen.h"
#include "../../include/controller/c/webots/receiver.h"
#include "../../include/controller/c/webots/robot.h"
#include "../../include/controller/c/webots/servo.h"
#include "../../include/controller/c/webots/supervisor.h"
#include "../../include/controller/c/webots/touch_sensor.h"
#include "../../include/controller/c/webots/utils/motion.h"
