function value = WB_NODE_ELEVATION_GRID
value = 9;
