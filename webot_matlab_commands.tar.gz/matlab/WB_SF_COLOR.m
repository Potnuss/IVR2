function value = WB_SF_COLOR
value = 7;
