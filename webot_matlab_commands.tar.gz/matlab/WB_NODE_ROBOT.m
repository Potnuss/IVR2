function value = WB_NODE_ROBOT
value = 40;
