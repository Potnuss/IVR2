function value = WB_NODE_EMITTER
value = 66;
