function value = WB_SF_INT32
value = 2;
