function value = WB_NODE_SUPERVISOR
value = 41;
