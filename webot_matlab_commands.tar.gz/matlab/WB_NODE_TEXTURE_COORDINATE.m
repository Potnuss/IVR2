function value = WB_NODE_TEXTURE_COORDINATE
value = 22;
