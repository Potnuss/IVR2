function wb_servo_disable_motor_force_feedback(tag)
% Usage: wb_servo_disable_motor_force_feedback(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_servo_disable_motor_force_feedback', tag);
