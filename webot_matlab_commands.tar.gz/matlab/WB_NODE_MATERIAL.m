function value = WB_NODE_MATERIAL
value = 16;
