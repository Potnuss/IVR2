function wb_distance_sensor_enable(tag, ms)
% Usage: wb_distance_sensor_enable(tag, ms)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_distance_sensor_enable', tag, ms);
