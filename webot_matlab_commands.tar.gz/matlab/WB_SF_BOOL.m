function value = WB_SF_BOOL
value = 1;
