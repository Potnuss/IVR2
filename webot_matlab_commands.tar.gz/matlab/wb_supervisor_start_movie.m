function wb_supervisor_start_movie(filename, width, height, type, quality)
% Usage: wb_supervisor_start_movie(filename, width, height, type, quality)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_supervisor_start_movie', filename, width, height, type, quality);
