function value = WB_ROBOT_KEYBOARD_NUMPAD_LEFT
value = 376;
