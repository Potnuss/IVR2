function value = WB_SF_ROTATION
value = 6;
