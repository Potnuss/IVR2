function value = WB_MF_INT32
value = 18;
