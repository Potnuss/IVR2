function value = WB_NODE_GROUP
value = 12;
