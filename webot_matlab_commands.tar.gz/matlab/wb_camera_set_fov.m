function wb_camera_set_fov(tag, fov)
% Usage: wb_camera_set_fov(tag, fov)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_camera_set_fov', tag, fov);
