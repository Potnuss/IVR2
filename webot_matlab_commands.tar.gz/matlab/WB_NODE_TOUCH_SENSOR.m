function value = WB_NODE_TOUCH_SENSOR
value = 77;
