function value = WB_NODE_DAMPING
value = 54;
