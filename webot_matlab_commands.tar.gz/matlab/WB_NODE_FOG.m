function value = WB_NODE_FOG
value = 11;
