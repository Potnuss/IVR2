function value = WB_NODE_COORDINATE
value = 6;
