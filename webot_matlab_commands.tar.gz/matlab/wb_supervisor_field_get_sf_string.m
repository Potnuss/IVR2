function result = wb_supervisor_field_get_sf_string(fieldref)
% Usage: wb_supervisor_field_get_sf_string(fieldref)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_supervisor_field_get_sf_string', fieldref);
