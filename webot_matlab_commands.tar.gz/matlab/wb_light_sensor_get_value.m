function result = wb_light_sensor_get_value(tag)
% Usage: wb_light_sensor_get_value(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_light_sensor_get_value', tag);
