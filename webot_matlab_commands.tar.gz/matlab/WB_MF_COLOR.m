function value = WB_MF_COLOR
value = 23;
