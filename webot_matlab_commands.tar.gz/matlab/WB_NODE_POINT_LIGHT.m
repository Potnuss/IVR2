function value = WB_NODE_POINT_LIGHT
value = 17;
