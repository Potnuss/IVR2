function result = wb_servo_get_position(tag)
% Usage: wb_servo_get_position(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_servo_get_position', tag);
