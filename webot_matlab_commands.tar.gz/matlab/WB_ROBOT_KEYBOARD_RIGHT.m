function value = WB_ROBOT_KEYBOARD_RIGHT
value = 316;
