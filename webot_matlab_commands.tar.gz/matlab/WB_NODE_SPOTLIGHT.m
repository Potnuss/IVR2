function value = WB_NODE_SPOTLIGHT
value = 20;
