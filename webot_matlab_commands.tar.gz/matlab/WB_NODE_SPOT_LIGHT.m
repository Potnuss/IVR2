function value = WB_NODE_SPOT_LIGHT
value = 20;
