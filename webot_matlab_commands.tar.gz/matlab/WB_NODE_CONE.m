function value = WB_NODE_CONE
value = 5;
