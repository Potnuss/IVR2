function value = WB_ROBOT_KEYBOARD_NUMPAD_HOME
value = 375;
