function value = WB_NODE_SPHERE
value = 19;
