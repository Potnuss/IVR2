function value = WB_NODE_SHAPE
value = 18;
