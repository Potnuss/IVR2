function value = WB_ROBOT_KEYBOARD_UP
value = 315;
