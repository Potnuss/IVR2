function value = WB_IMAGE_RGBA
value = 4;
