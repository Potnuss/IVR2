function value = WB_NODE_INDEXED_FACE_SET
value = 14;
