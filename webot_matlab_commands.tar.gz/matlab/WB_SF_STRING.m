function value = WB_SF_STRING
value = 8;
