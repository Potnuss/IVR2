function value = WB_NODE_APPEARANCE
value = 1;
