function value = WB_NODE_COLOR
value = 4;
