function value = WB_NODE_NO_NODE
value = 0;
