function value = WB_NODE_INDEXED_LINE_SET
value = 15;
