function value = WB_NODE_VIEWPOINT
value = 25;
