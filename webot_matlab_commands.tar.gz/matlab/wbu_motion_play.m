function wbu_motion_play(motionref)
% Usage: wbu_motion_play(motionref)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wbu_motion_play', motionref);
