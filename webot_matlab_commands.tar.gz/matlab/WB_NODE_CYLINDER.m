function value = WB_NODE_CYLINDER
value = 7;
