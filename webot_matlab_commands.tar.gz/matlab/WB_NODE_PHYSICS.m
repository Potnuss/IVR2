function value = WB_NODE_PHYSICS
value = 51;
