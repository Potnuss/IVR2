function value = WB_NODE_DISTANCE_SENSOR
value = 65;
