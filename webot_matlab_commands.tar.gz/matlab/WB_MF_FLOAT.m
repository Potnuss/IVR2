function value = WB_MF_FLOAT
value = 19;
