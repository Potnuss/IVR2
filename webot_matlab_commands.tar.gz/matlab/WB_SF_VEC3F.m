function value = WB_SF_VEC3F
value = 5;
