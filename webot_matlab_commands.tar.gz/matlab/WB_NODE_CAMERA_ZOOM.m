function value = WB_NODE_CAMERA_ZOOM
value = 52;
