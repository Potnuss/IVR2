function value = WB_NODE_EXTRUSION
value = 10;
