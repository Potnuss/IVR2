function value = WB_CHANNEL_BROADCAST
value = -1;
