function wb_supervisor_field_set_sf_float(fieldref, value)
% Usage: wb_supervisor_field_set_sf_float(fieldref, value)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_supervisor_field_set_sf_float', fieldref, value);
