function value = WB_SF_VEC2F
value = 4;
