function value = WB_ROBOT_KEYBOARD_LEFT
value = 314;
