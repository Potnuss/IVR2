function value = WB_ROBOT_KEYBOARD_KEY
value = 65535;
