function wbu_motion_set_reverse(motionref, reverse)
% Usage: wbu_motion_set_reverse(motionref, reverse)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wbu_motion_set_reverse', motionref, reverse);
