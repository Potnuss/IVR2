function result = wb_emitter_get_buffer_size(tag)
% Usage: wb_emitter_get_buffer_size(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_emitter_get_buffer_size', tag);
