function value = WB_NODE_LED
value = 69;
