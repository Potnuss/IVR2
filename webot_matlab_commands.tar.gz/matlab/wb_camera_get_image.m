function rgb = wb_camera_get_image(tag)
% Usage: wb_camera_get_image(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

width = calllib('libController', 'wb_camera_get_width', tag);
height = calllib('libController', 'wb_camera_get_height', tag);
pointer = calllib('libController', 'wb_camera_get_image',tag);
setdatatype(pointer, 'uint8Ptr', 3 * width * height, 1);
rgb = permute(reshape(get(pointer, 'Value'), 3, width, height), [3 2 1]);
