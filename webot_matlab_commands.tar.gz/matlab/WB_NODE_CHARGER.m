function value = WB_NODE_CHARGER
value = 53;
