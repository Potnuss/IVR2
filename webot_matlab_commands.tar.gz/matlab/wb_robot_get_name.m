function result = wb_robot_get_name()
% Usage: wb_robot_get_name()
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_robot_get_name');
