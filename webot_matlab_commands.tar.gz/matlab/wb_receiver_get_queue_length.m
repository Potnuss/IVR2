function result = wb_receiver_get_queue_length(tag)
% Usage: wb_receiver_get_queue_length(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_receiver_get_queue_length', tag);
