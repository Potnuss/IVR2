function wb_led_set(tag, value)
% Usage: wb_led_set(tag, value)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_led_set', tag, value);
