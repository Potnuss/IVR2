function value = WB_MF_VEC2F
value = 20;
