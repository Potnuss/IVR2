function value = WB_NODE_SOLID
value = 50;
