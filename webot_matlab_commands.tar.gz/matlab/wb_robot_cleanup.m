function wb_robot_cleanup()
% Usage: wb_robot_cleanup()
% Matlab API for Webots
% This is a dummy function: it does nothing
