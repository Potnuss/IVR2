function wbu_motion_set_loop(motionref, loop)
% Usage: wbu_motion_set_loop(motionref, loop)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wbu_motion_set_loop', motionref, loop);
