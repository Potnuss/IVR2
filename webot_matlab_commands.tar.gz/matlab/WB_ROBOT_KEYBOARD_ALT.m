function value = WB_ROBOT_KEYBOARD_ALT
value = 262144;
