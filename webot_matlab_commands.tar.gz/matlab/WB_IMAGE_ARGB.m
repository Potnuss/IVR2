function value = WB_IMAGE_ARGB
value = 5;
