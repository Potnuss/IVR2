function value = WB_CAMERA_RANGE_FINDER
value = 114;
