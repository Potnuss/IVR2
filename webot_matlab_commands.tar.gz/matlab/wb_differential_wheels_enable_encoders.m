function wb_differential_wheels_enable_encoders(ms)
% Usage: wb_differential_wheels_enable_encoders(ms)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_differential_wheels_enable_encoders', ms);
