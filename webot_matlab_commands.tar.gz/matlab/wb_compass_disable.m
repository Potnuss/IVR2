function wb_compass_disable(tag)
% Usage: wb_compass_disable(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_compass_disable', tag);
