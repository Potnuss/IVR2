function value = WB_NODE_TRANSFORM
value = 24;
