function wb_pen_write(tag, write)
% Usage: wb_pen_write(tag, write)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_pen_write', tag, write);
