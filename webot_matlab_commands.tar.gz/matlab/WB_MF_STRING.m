function value = WB_MF_STRING
value = 24;
