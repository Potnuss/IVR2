function value = WB_NODE_GPS
value = 67;
