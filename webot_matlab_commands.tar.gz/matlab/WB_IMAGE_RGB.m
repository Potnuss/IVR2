function value = WB_IMAGE_RGB
value = 3;
