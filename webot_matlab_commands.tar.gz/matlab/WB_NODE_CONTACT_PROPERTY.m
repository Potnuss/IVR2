function value = WB_NODE_CONTACT_PROPERTY
value = 55;
