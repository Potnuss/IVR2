function value = WB_NODE_DIFFERENTIAL_WHEELS
value = 42;
