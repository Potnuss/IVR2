function value = WB_NODE_RECEIVER
value = 74;
