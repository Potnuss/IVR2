function value = WB_NODE_ACCELEROMETER
value = 60;
