function value = WB_NODE_WORLD_INFO
value = 26;
