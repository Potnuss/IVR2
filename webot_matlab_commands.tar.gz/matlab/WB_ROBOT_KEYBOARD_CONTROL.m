function value = WB_ROBOT_KEYBOARD_CONTROL
value = 131072;
