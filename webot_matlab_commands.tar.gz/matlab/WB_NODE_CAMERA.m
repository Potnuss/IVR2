function value = WB_NODE_CAMERA
value = 61;
