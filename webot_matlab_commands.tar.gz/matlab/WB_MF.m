function value = WB_MF
value = 16;
