function value = WB_NODE_LIGHT_SENSOR
value = 70;
