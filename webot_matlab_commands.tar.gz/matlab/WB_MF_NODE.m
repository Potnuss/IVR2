function value = WB_MF_NODE
value = 25;
