% launcher script for MATLAB controllers
% this script is an interface between Webots and the .m controller
% Webots MATLAB API
% Author: Yvan Bourquin - www.cyberbotics.com

% useful env variables supplied by webots
WEBOTS_PROJECT = getenv('WEBOTS_PROJECT');
WEBOTS_HOME = getenv('WEBOTS_HOME');
WEBOTS_CONTROLLER_NAME = getenv('WEBOTS_CONTROLLER_NAME');
WEBOTS_VERSION = getenv('WEBOTS_VERSION');

if isempty(WEBOTS_HOME) || isempty(WEBOTS_CONTROLLER_NAME) || isempty(WEBOTS_VERSION)
  error('launcher.m must be called from Webots.');
end

% add path to libController and to Webots API m-files
addpath([WEBOTS_HOME '/lib']);
addpath([WEBOTS_HOME '/lib/matlab']);

if isunix
  libname = 'libController';
else
  libname = 'Controller';
end

try
  % work in the system's temp dir so we have write access
  cd(tempdir);

  % creates the base name of the protofile (without .m extension)
  % we make the name dependant on matlab and webots versions, so a new file will be generated for any version change
  % we need to replace the dots by underscores, because dots cause problems in the protofile
  protofile = strrep(['protofile_matlab_' version('-release') '_webots_' WEBOTS_VERSION], '.', '_');

  % another controller is currently generating the proto file: need to wait
  lockfile = 'webots_matlab_lock';
  while exist(lockfile, 'file')
    pause(1);
  end

  if ~exist([protofile '.m'], 'file')

    % create a lock to prevent any other matlab controller from generating the proto file simultaneously
    fid = fopen(lockfile, 'w');
    fclose(fid);

    disp(['creating: ' tempdir protofile '.m']);
    try
      loadlibrary( ...
        libname,'allincludes.h', ...
        'mfilename',protofile, ...
        'alias','libController', ...
        'addheader','accelerometer.h', ...
        'addheader','camera.h', ...
        'addheader','compass.h', ...
        'addheader','connector.h', ...
        'addheader','differential_wheels.h', ...
        'addheader','display.h', ...
        'addheader','distance_sensor.h', ...
        'addheader','emitter.h', ...
        'addheader','gps.h', ...
        'addheader','gyro.h', ...
        'addheader','led.h', ...
        'addheader','light_sensor.h', ...
        'addheader','pen.h', ...
        'addheader','receiver.h', ...
        'addheader','robot.h', ...
        'addheader','servo.h', ...
        'addheader','supervisor.h', ...
        'addheader','touch_sensor.h', ...
        'addheader',['utils' filesep 'motion.h']);
    catch ME
      % if anything fails, remove the lockfile otherwise everything will be blocked forever
      delete(lockfile);
      rethrow(ME);
    end
    delete(lockfile);
  else
    loadlibrary(libname,protofile,'alias','libController');
  end

  % initialize libController and redirect stdout/stderr
  try
    calllib('libController', 'wb_robot_init');
  catch
    calllib('libController', 'wb_robot_init_msvc');
  end

  % start controller
  cd([WEBOTS_PROJECT '/controllers/' WEBOTS_CONTROLLER_NAME]);
  eval(WEBOTS_CONTROLLER_NAME);

catch ME
  % display error message in Webots console
  % use stderr to display message in red (this does not work on Windows)
  fprintf(2,'%s\n\n',getReport(ME, 'extended'));
  quit;
end
