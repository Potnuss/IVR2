function value = WB_NODE_CAPSULE
value = 30;
