function value = WB_NODE_PLANE
value = 31;
