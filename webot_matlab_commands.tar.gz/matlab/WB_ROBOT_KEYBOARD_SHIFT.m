function value = WB_ROBOT_KEYBOARD_SHIFT
value = 65536;
