function value = WB_NODE_SERVO
value = 75;
