function value = WB_NODE_DISPLAY
value = 64;
