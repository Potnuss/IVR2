function wb_servo_set_control_p(tag, p)
% Usage: wb_servo_set_control_p(tag, p)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

calllib('libController', 'wb_servo_set_control_p', tag, p);
