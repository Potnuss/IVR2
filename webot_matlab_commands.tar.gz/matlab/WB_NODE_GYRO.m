function value = WB_NODE_GYRO
value = 68;
