function value = WB_NODE_TEXTURE_TRANSFORM
value = 23;
