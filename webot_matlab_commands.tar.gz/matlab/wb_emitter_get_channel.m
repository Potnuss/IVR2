function result = wb_emitter_get_channel(tag)
% Usage: wb_emitter_get_channel(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

result = calllib('libController', 'wb_emitter_get_channel', tag);
