function value = WB_NODE_CONNECTOR
value = 63;
