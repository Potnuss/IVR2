function value = WB_NODE_BOX
value = 3;
