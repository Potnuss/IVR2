function value = WB_NODE_DIRECTIONAL_LIGHT
value = 8;
