function value = WB_NODE_COMPASS
value = 62;
