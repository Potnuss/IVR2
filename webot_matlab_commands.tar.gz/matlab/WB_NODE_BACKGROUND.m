function value = WB_NODE_BACKGROUND
value = 2;
