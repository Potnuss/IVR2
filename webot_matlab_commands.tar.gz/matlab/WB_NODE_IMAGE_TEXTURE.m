function value = WB_NODE_IMAGE_TEXTURE
value = 13;
