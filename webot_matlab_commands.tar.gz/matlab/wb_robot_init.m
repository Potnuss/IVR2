function wb_robot_init()
% Usage: wb_robot_init()
% Matlab API for Webots
% This is a dummy function: it does nothing
