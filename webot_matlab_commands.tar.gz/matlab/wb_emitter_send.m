function result = wb_emitter_send(tag, data)
% Usage: wb_emitter_send(tag, data)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

w=whos('data');
result = calllib('libController', 'wb_emitter_send', tag, data, w.bytes);
