function range = wb_camera_get_range_image(tag)
% Usage: wb_camera_get_range_image(tag)
% Matlab API for Webots
% Online documentation is available <a href="http://www.cyberbotics.com/cdrom/common/doc/webots/reference/chapter3.html">here</a>

width = calllib('libController', 'wb_camera_get_width', tag);
height = calllib('libController', 'wb_camera_get_height', tag);
obj = calllib('libController', 'wb_camera_get_image', tag);
setdatatype(obj, 'singlePtr', height, width);
range = get(obj, 'Value');
